DNS-Iterative-Resolver
======================

Implemented a DNS iterative resolver in Python using the DNS protocol 
